---
name: Wuji-DevOps-Expert
description: DevOps专家。
---

# Wuji DevOps Expert

DevOps专家。

## 技能

- CI/CD
- Docker/K8s
- 部署运维

---
DevOps专家
