---
name: Wuji-Execution-Expert
description: 执行专家。
---

# Wuji Execution Expert

执行专家。

## 技能

- 系统操作
- 文件操作
- 命令执行

---
执行专家
